package com.example.quicktile

import android.appwidget.AppWidgetManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.view.View
import android.widget.RemoteViews
import android.widget.RemoteViewsService

class TileWidgetService : RemoteViewsService() {
    override fun onGetViewFactory(intent: Intent): RemoteViewsFactory {
        val widgetId = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
        return TileRemoteViewsFactory(applicationContext, widgetId)
    }
}

class TileRemoteViewsFactory(private val context: Context, private val widgetId: Int) : RemoteViewsService.RemoteViewsFactory {
    private var packages = listOf<String>()
    private var showLabels = true
    private var isDark = true
    private var iconSizePx = 128

    override fun onCreate() {}

    override fun onDataSetChanged() {
        val prefs = context.getSharedPreferences("QuickTilePrefs", Context.MODE_PRIVATE)
        val raw = prefs.getString("order_$widgetId", "") ?: ""
        packages = if (raw.isEmpty()) emptyList() else raw.split(",").filter { it.isNotEmpty() }
        showLabels = prefs.getBoolean("labels_$widgetId", true)
        isDark = prefs.getBoolean("dark_$widgetId", true)
        val iconDp = prefs.getInt("iconsize_$widgetId", 48)
        iconSizePx = (iconDp * context.resources.displayMetrics.density).toInt().coerceAtLeast(48)
    }

    override fun onDestroy() {}
    override fun getCount(): Int = packages.size

    override fun getViewAt(position: Int): RemoteViews {
        val views = RemoteViews(context.packageName, R.layout.widget_item)
        if (position >= packages.size) return views

        val pkg = packages[position]
        val pm = context.packageManager

        try {
            val appInfo = pm.getApplicationInfo(pkg, 0)
            val label = pm.getApplicationLabel(appInfo).toString()
            val iconBitmap = drawableToBitmap(pm.getApplicationIcon(appInfo), iconSizePx)

            views.setImageViewBitmap(R.id.item_icon, iconBitmap)

            if (showLabels) {
                views.setViewVisibility(R.id.item_label, View.VISIBLE)
                views.setTextViewText(R.id.item_label, label)
                views.setTextColor(R.id.item_label, if (isDark) Color.WHITE else Color.parseColor("#1C1C1E"))
            } else {
                views.setViewVisibility(R.id.item_label, View.GONE)
            }

            val fillInIntent = Intent().apply { putExtra("PACKAGE_NAME", pkg) }
            views.setOnClickFillInIntent(R.id.item_root, fillInIntent)
        } catch (e: Exception) {
            views.setTextViewText(R.id.item_label, "")
        }
        return views
    }

    override fun getLoadingView(): RemoteViews? = null
    override fun getViewTypeCount(): Int = 1
    override fun getItemId(position: Int): Long = position.toLong()
    override fun hasStableIds(): Boolean = true

    private fun drawableToBitmap(drawable: Drawable, size: Int): Bitmap {
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        drawable.setBounds(0, 0, canvas.width, canvas.height)
        drawable.draw(canvas)
        return bitmap
    }
}
