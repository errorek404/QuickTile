package com.example.quicktile

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*

data class AppEntry(
    val packageName: String,
    val label: String,
    val icon: Drawable,
    var selected: Boolean
)

class ConfigActivity : Activity() {
    private var appWidgetId = AppWidgetManager.INVALID_APPWIDGET_ID
    private val allApps = mutableListOf<AppEntry>()
    private val displayedApps = mutableListOf<AppEntry>()
    private lateinit var adapter: AppListAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setResult(RESULT_CANCELED)
        setContentView(R.layout.activity_config)

        appWidgetId = intent?.extras?.getInt(
            AppWidgetManager.EXTRA_APPWIDGET_ID,
            AppWidgetManager.INVALID_APPWIDGET_ID
        ) ?: AppWidgetManager.INVALID_APPWIDGET_ID

        if (appWidgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish()
            return
        }

        val prefs = getSharedPreferences("QuickTilePrefs", Context.MODE_PRIVATE)
        val savedOrder = (prefs.getString("order_$appWidgetId", "") ?: "")
            .split(",").filter { it.isNotEmpty() }
        val isDark = prefs.getBoolean("dark_$appWidgetId", true)
        val opacity = prefs.getInt("opacity_$appWidgetId", 50)
        val radius = prefs.getInt("radius_$appWidgetId", 24)
        val iconSize = prefs.getInt("iconsize_$appWidgetId", 48)
        val cols = prefs.getInt("cols_$appWidgetId", 4)
        val showLabels = prefs.getBoolean("labels_$appWidgetId", true)

        val rbDark = findViewById<RadioButton>(R.id.rb_dark)
        val rbLight = findViewById<RadioButton>(R.id.rb_light)
        if (isDark) rbDark.isChecked = true else rbLight.isChecked = true

        val tvOpacity = findViewById<TextView>(R.id.tv_opacity)
        val sbOpacity = findViewById<SeekBar>(R.id.sb_opacity)
        sbOpacity.progress = opacity
        tvOpacity.text = "Krycie tła: $opacity%"
        sbOpacity.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, f: Boolean) {
                tvOpacity.text = "Krycie tła: $p%"
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        val tvRadius = findViewById<TextView>(R.id.tv_radius)
        val sbRadius = findViewById<SeekBar>(R.id.sb_radius)
        sbRadius.progress = radius
        tvRadius.text = "Rogi: ${radius} dp"
        sbRadius.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, f: Boolean) {
                tvRadius.text = "Rogi: ${p} dp"
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        val tvIconSize = findViewById<TextView>(R.id.tv_icon_size)
        val sbIconSize = findViewById<SeekBar>(R.id.sb_icon_size)
        sbIconSize.progress = (iconSize - 32).coerceIn(0, 36)
        tvIconSize.text = "Ikony: ${iconSize} dp"
        sbIconSize.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, f: Boolean) {
                tvIconSize.text = "Ikony: ${p + 32} dp"
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        when (cols) {
            3 -> findViewById<RadioButton>(R.id.rb_col3).isChecked = true
            5 -> findViewById<RadioButton>(R.id.rb_col5).isChecked = true
            6 -> findViewById<RadioButton>(R.id.rb_col6).isChecked = true
            else -> findViewById<RadioButton>(R.id.rb_col4).isChecked = true
        }

        val cbLabels = findViewById<CheckBox>(R.id.cb_show_labels)
        cbLabels.isChecked = showLabels

        loadApps(savedOrder)

        val lvApps = findViewById<ListView>(R.id.lv_apps)
        adapter = AppListAdapter()
        lvApps.adapter = adapter

        val etSearch = findViewById<EditText>(R.id.et_search)
        etSearch.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                filterApps(s?.toString() ?: "")
            }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        findViewById<Button>(R.id.btn_save).setOnClickListener {
            val selectedPkgs = allApps.filter { it.selected }.map { it.packageName }
            val chosenCols = when (findViewById<RadioGroup>(R.id.rg_cols).checkedRadioButtonId) {
                R.id.rb_col3 -> 3
                R.id.rb_col5 -> 5
                R.id.rb_col6 -> 6
                else -> 4
            }

            prefs.edit()
                .putString("order_$appWidgetId", selectedPkgs.joinToString(","))
                .putBoolean("dark_$appWidgetId", rbDark.isChecked)
                .putInt("opacity_$appWidgetId", sbOpacity.progress)
                .putInt("radius_$appWidgetId", sbRadius.progress)
                .putInt("iconsize_$appWidgetId", sbIconSize.progress + 32)
                .putInt("cols_$appWidgetId", chosenCols)
                .putBoolean("labels_$appWidgetId", cbLabels.isChecked)
                .apply()

            val manager = AppWidgetManager.getInstance(this)
            TileWidgetProvider.updateAppWidget(this, manager, appWidgetId)

            val resultValue = Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId)
            setResult(RESULT_OK, resultValue)
            finish()
        }
    }

    private fun loadApps(savedOrder: List<String>) {
        val pm = packageManager
        val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val rawMap = pm.queryIntentActivities(mainIntent, 0)
            .distinctBy { it.activityInfo.packageName }
            .associateBy { it.activityInfo.packageName }

        val added = mutableSetOf<String>()
        for (pkg in savedOrder) {
            val info = rawMap[pkg] ?: continue
            allApps.add(AppEntry(pkg, info.loadLabel(pm).toString(), info.loadIcon(pm), true))
            added.add(pkg)
        }

        val rest = rawMap.values
            .filter { !added.contains(it.activityInfo.packageName) }
            .map {
                AppEntry(
                    it.activityInfo.packageName,
                    it.loadLabel(pm).toString(),
                    it.loadIcon(pm),
                    false
                )
            }
            .sortedBy { it.label.lowercase() }

        allApps.addAll(rest)
        displayedApps.addAll(allApps)
    }

    private fun filterApps(query: String) {
        val q = query.trim().lowercase()
        displayedApps.clear()
        if (q.isEmpty()) {
            displayedApps.addAll(allApps)
        } else {
            displayedApps.addAll(allApps.filter { it.label.lowercase().contains(q) })
        }
        adapter.notifyDataSetChanged()
    }

    inner class AppListAdapter : BaseAdapter() {
        override fun getCount(): Int = displayedApps.size
        override fun getItem(pos: Int): AppEntry = displayedApps[pos]
        override fun getItemId(pos: Int): Long = pos.toLong()

        override fun getView(pos: Int, convertView: View?, parent: ViewGroup): View {
            val view = convertView ?: LayoutInflater.from(this@ConfigActivity)
                .inflate(R.layout.item_app_config, parent, false)

            val entry = displayedApps[pos]
            val cb = view.findViewById<CheckBox>(R.id.item_cb)
            val icon = view.findViewById<ImageView>(R.id.item_app_icon)
            val name = view.findViewById<TextView>(R.id.item_app_name)
            val btnUp = view.findViewById<ImageButton>(R.id.btn_up)
            val btnDown = view.findViewById<ImageButton>(R.id.btn_down)

            cb.setOnCheckedChangeListener(null)
            cb.isChecked = entry.selected
            icon.setImageDrawable(entry.icon)
            name.text = entry.label

            val toggleAction = {
                entry.selected = !entry.selected
                cb.isChecked = entry.selected
                if (entry.selected) {
                    allApps.remove(entry)
                    val insertIdx = allApps.indexOfFirst { !it.selected }.let { if (it == -1) allApps.size else it }
                    allApps.add(insertIdx, entry)
                    filterApps(findViewById<EditText>(R.id.et_search).text.toString())
                }
            }

            cb.setOnClickListener {
                entry.selected = cb.isChecked
                if (entry.selected) {
                    allApps.remove(entry)
                    val insertIdx = allApps.indexOfFirst { !it.selected }.let { if (it == -1) allApps.size else it }
                    allApps.add(insertIdx, entry)
                    filterApps(findViewById<EditText>(R.id.et_search).text.toString())
                }
            }
            view.setOnClickListener { toggleAction() }

            val isSearching = findViewById<EditText>(R.id.et_search).text.isNotEmpty()
            btnUp.visibility = if (entry.selected && !isSearching) View.VISIBLE else View.INVISIBLE
            btnDown.visibility = if (entry.selected && !isSearching) View.VISIBLE else View.INVISIBLE

            btnUp.setOnClickListener {
                val idx = allApps.indexOf(entry)
                if (idx > 0) {
                    allApps.removeAt(idx)
                    allApps.add(idx - 1, entry)
                    filterApps("")
                }
            }

            btnDown.setOnClickListener {
                val idx = allApps.indexOf(entry)
                if (idx != -1 && idx < allApps.size - 1 && allApps[idx + 1].selected) {
                    allApps.removeAt(idx)
                    allApps.add(idx + 1, entry)
                    filterApps("")
                }
            }

            return view
        }
    }
}
