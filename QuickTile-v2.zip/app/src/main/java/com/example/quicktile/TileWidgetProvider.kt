package com.example.quicktile

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.net.Uri
import android.widget.RemoteViews

class TileWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (appWidgetId in appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId)
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            "ACTION_LAUNCH_APP" -> {
                val pkg = intent.getStringExtra("PACKAGE_NAME") ?: return
                val launchIntent = context.packageManager.getLaunchIntentForPackage(pkg)
                launchIntent?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                if (launchIntent != null) {
                    context.startActivity(launchIntent)
                }
            }
            Intent.ACTION_MY_PACKAGE_REPLACED -> {
                val manager = AppWidgetManager.getInstance(context)
                val ids = manager.getAppWidgetIds(ComponentName(context, TileWidgetProvider::class.java))
                onUpdate(context, manager, ids)
            }
        }
    }

    companion object {
        fun updateAppWidget(context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int) {
            val prefs = context.getSharedPreferences("QuickTilePrefs", Context.MODE_PRIVATE)
            val cols = prefs.getInt("cols_$appWidgetId", 4)
            val isDark = prefs.getBoolean("dark_$appWidgetId", true)
            val opacity = prefs.getInt("opacity_$appWidgetId", 50)
            val radiusDp = prefs.getInt("radius_$appWidgetId", 24)

            val layoutId = when (cols) {
                3 -> R.layout.widget_layout_3
                5 -> R.layout.widget_layout_5
                6 -> R.layout.widget_layout_6
                else -> R.layout.widget_layout_4
            }

            val serviceIntent = Intent(context, TileWidgetService::class.java).apply {
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId)
                data = Uri.parse(toUri(Intent.URI_INTENT_SCHEME))
            }

            val bgBitmap = createRoundedBgBitmap(context, isDark, opacity, radiusDp)

            val views = RemoteViews(context.packageName, layoutId).apply {
                setImageViewBitmap(R.id.widget_bg_image, bgBitmap)
                setRemoteAdapter(R.id.widget_grid, serviceIntent)
            }

            val clickIntent = Intent(context, TileWidgetProvider::class.java).apply {
                action = "ACTION_LAUNCH_APP"
            }
            val clickPendingIntent = PendingIntent.getBroadcast(
                context, appWidgetId, clickIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
            )
            views.setPendingIntentTemplate(R.id.widget_grid, clickPendingIntent)

            appWidgetManager.updateAppWidget(appWidgetId, views)
            appWidgetManager.notifyAppWidgetViewDataChanged(appWidgetId, R.id.widget_grid)
        }

        private fun createRoundedBgBitmap(context: Context, isDark: Boolean, opacityPercent: Int, radiusDp: Int): Bitmap {
            val density = context.resources.displayMetrics.density
            val w = (360 * density).toInt()
            val h = (200 * density).toInt()
            val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)

            val alpha = ((opacityPercent.coerceIn(0, 100) / 100f) * 255).toInt()
            val baseColor = if (isDark) Color.rgb(28, 28, 30) else Color.rgb(245, 245, 247)
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.argb(alpha, Color.red(baseColor), Color.green(baseColor), Color.blue(baseColor))
            }

            val r = radiusDp * density
            canvas.drawRoundRect(RectF(0f, 0f, w.toFloat(), h.toFloat()), r, r, paint)
            return bitmap
        }
    }
}
