package com.example.quicktile

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.RemoteViews

class TileWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (appWidgetId in appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId)
        }
    }

    override fun onDeleted(context: Context, appWidgetIds: IntArray) {
        val prefs = context.getSharedPreferences("QuickTilePrefs", Context.MODE_PRIVATE).edit()
        for (id in appWidgetIds) {
            prefs.remove("widget_apps_$id")
            prefs.remove("widget_bg_$id")
            prefs.remove("widget_labels_$id")
        }
        prefs.apply()
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == "ACTION_LAUNCH_APP") {
            val pkg = intent.getStringExtra("PACKAGE_NAME") ?: return
            val launchIntent = context.packageManager.getLaunchIntentForPackage(pkg)
            launchIntent?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (launchIntent != null) {
                context.startActivity(launchIntent)
            }
        }
    }

    companion object {
        fun updateAppWidget(context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int) {
            val prefs = context.getSharedPreferences("QuickTilePrefs", Context.MODE_PRIVATE)
            val bgMode = prefs.getInt("widget_bg_$appWidgetId", 0)

            val bgRes = when (bgMode) {
                1 -> R.drawable.widget_bg_light
                2 -> R.drawable.widget_bg_transparent
                else -> R.drawable.widget_bg_dark
            }

            val serviceIntent = Intent(context, TileWidgetService::class.java).apply {
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId)
                data = Uri.parse(toUri(Intent.URI_INTENT_SCHEME))
            }

            val views = RemoteViews(context.packageName, R.layout.widget_layout).apply {
                setInt(R.id.widget_container, "setBackgroundResource", bgRes)
                setRemoteAdapter(R.id.widget_grid, serviceIntent)
            }

            val clickIntent = Intent(context, TileWidgetProvider::class.java).apply {
                action = "ACTION_LAUNCH_APP"
            }
            val clickPendingIntent = PendingIntent.getBroadcast(
                context, appWidgetId, clickIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
            )
            views.setPendingIntentTemplate(R.id.widget_grid, clickPendingIntent)

            appWidgetManager.updateAppWidget(appWidgetId, views)
            appWidgetManager.notifyAppWidgetViewDataChanged(appWidgetId, R.id.widget_grid)
        }
    }
}
