package com.example.quicktile

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView

data class AppEntry(val pkg: String, val label: String, var selected: Boolean)

class ConfigActivity : Activity() {
    private var appWidgetId = AppWidgetManager.INVALID_APPWIDGET_ID
    private val appList = mutableListOf<AppEntry>()
    private lateinit var adapter: AppListAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setResult(RESULT_CANCELED)

        appWidgetId = intent?.extras?.getInt(
            AppWidgetManager.EXTRA_APPWIDGET_ID,
            AppWidgetManager.INVALID_APPWIDGET_ID
        ) ?: AppWidgetManager.INVALID_APPWIDGET_ID

        if (appWidgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish()
            return
        }

        val prefs = getSharedPreferences("QuickTilePrefs", Context.MODE_PRIVATE)
        val savedRaw = prefs.getString("widget_apps_$appWidgetId", "") ?: ""
        val savedOrder = if (savedRaw.isEmpty()) emptyList() else savedRaw.split(",").filter { it.isNotBlank() }
        val savedBg = prefs.getInt("widget_bg_$appWidgetId", 0)
        val savedLabels = prefs.getBoolean("widget_labels_$appWidgetId", true)

        val pm = packageManager
        val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val installed = pm.queryIntentActivities(mainIntent, 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .distinctBy { it.first }
            .toMap()

        for (pkg in savedOrder) {
            val label = installed[pkg]
            if (label != null) {
                appList.add(AppEntry(pkg, label, true))
            }
        }
        val remaining = installed.filterKeys { !savedOrder.contains(it) }
            .toList()
            .sortedBy { it.second.lowercase() }
        for ((pkg, label) in remaining) {
            appList.add(AppEntry(pkg, label, false))
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 32)
            setBackgroundColor(Color.parseColor("#121212"))
        }

        val bgTitle = TextView(this).apply {
            text = "Tło widżetu:"
            setTextColor(Color.WHITE)
            textSize = 15f
        }
        root.addView(bgTitle)

        val bgGroup = RadioGroup(this).apply {
            orientation = RadioGroup.HORIZONTAL
        }
        val bgOptions = listOf("Ciemne", "Jasne", "Przezroczyste")
        bgOptions.forEachIndexed { index, title ->
            val rb = RadioButton(this).apply {
                id = 100 + index
                text = title
                setTextColor(Color.WHITE)
                isChecked = (savedBg == index)
            }
            bgGroup.addView(rb)
        }
        root.addView(bgGroup)

        val labelCheck = CheckBox(this).apply {
            text = "Pokaż nazwy aplikacji pod ikonami"
            setTextColor(Color.WHITE)
            isChecked = savedLabels
        }
        root.addView(labelCheck)

        val hintText = TextView(this).apply {
            text = "Zaznacz aplikacje i użyj strzałek, aby ustawić kolejność:"
            setTextColor(Color.LTGRAY)
            textSize = 13f
            setPadding(0, 16, 0, 8)
        }
        root.addView(hintText)

        adapter = AppListAdapter()
        val listView = ListView(this).apply {
            adapter = this@ConfigActivity.adapter
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
            )
        }
        root.addView(listView)

        val saveBtn = Button(this).apply {
            text = "Zapisz widżet"
            setOnClickListener {
                val selectedPkgs = appList.filter { it.selected }.joinToString(",") { it.pkg }
                val selectedBg = when (bgGroup.checkedRadioButtonId) {
                    101 -> 1
                    102 -> 2
                    else -> 0
                }
                prefs.edit()
                    .putString("widget_apps_$appWidgetId", selectedPkgs)
                    .putInt("widget_bg_$appWidgetId", selectedBg)
                    .putBoolean("widget_labels_$appWidgetId", labelCheck.isChecked)
                    .apply()

                val appWidgetManager = AppWidgetManager.getInstance(this@ConfigActivity)
                TileWidgetProvider.updateAppWidget(this@ConfigActivity, appWidgetManager, appWidgetId)

                val resultValue = Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId)
                setResult(RESULT_OK, resultValue)
                finish()
            }
        }
        root.addView(saveBtn)

        setContentView(root)
    }

    inner class AppListAdapter : BaseAdapter() {
        override fun getCount(): Int = appList.size
        override fun getItem(position: Int): Any = appList[position]
        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val row = LinearLayout(this@ConfigActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(8, 12, 8, 12)
            }
            val item = appList[position]

            val cb = CheckBox(this@ConfigActivity).apply {
                text = item.label
                setTextColor(Color.WHITE)
                isChecked = item.selected
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                setOnCheckedChangeListener { _, isChecked ->
                    item.selected = isChecked
                }
            }

            val upBtn = Button(this@ConfigActivity).apply {
                text = "▲"
                layoutParams = LinearLayout.LayoutParams(110, 100)
                setOnClickListener {
                    if (position > 0) {
                        val temp = appList[position - 1]
                        appList[position - 1] = item
                        appList[position] = temp
                        notifyDataSetChanged()
                    }
                }
            }

            val downBtn = Button(this@ConfigActivity).apply {
                text = "▼"
                layoutParams = LinearLayout.LayoutParams(110, 100)
                setOnClickListener {
                    if (position < appList.size - 1) {
                        val temp = appList[position + 1]
                        appList[position + 1] = item
                        appList[position] = temp
                        notifyDataSetChanged()
                    }
                }
            }

            row.addView(cb)
            row.addView(upBtn)
            row.addView(downBtn)
            return row
        }
    }
}
